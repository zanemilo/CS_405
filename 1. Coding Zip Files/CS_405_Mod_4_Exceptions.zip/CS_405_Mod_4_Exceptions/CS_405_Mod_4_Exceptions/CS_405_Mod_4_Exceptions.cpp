// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Author: Zane Deso

#include <iostream>
#include <exception>
#include <stdexcept>


class custom_exception : public std::exception {  // Custom exception class
public:
    virtual const char* what() const noexcept override {    // Extends std::exception
        return "Custom Exception";
    }
};

bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::exception("Standard exception"); // Throws the standard exception
    
    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic())  // Throws std::exception && returns true
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {  // Catch and handle std::exception
        std::cout << "Exception caught in do_custom_application_logic(): " << e.what() << std::endl;
    }

    throw custom_exception();  // Throws custom exception extended from std::exception

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    if (den == 0) {
        throw std::runtime_error("Divide by zero exception"); // Throw exception for div by zero
    }

    return (num / den);
}

void do_division() noexcept
{

    float numerator = 10.0f;
    float denominator = 0;
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::runtime_error& e) {  // Catch and handle std::runtime_error divide by zero exception
        std::cout << "Divide by zero exception caught: " << e.what() << std::endl;
    }
    
}

int main()
{
    try { // Wrap main function calls in try-catch to catch and handle exceptions
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic();
    }
    catch (const custom_exception& e) {  // Catch custom exception
        std::cout << "Custom exception caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e) { // Catch standard exception
        std::cout << "Standard exception caught in main: " << e.what() << std::endl;
    }
    catch (...) { // Catch all remaining unkown exceptions
        std::cout << "Unkown error caught in main: " << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
